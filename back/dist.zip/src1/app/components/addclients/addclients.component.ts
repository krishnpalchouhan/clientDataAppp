import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-addclients',
  templateUrl: './addclients.component.html',
  styleUrls: ['./addclients.component.css']
})
export class AddclientsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
