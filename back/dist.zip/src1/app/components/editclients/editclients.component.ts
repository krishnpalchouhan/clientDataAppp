import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-editclients',
  templateUrl: './editclients.component.html',
  styleUrls: ['./editclients.component.css']
})
export class EditclientsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
