import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-clients-details',
  templateUrl: './clients-details.component.html',
  styleUrls: ['./clients-details.component.css']
})
export class ClientsDetailsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
